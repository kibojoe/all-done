# kibojoe.github.io
Website Kibojoe Linux sources.

- Kibojoe is a beautiful light-weight and easy to use Linux distribution based on Manjaro-
- Kibojoe Linux is shipped with a stable light and cofigurable Joe's Window Manager (JWM)-
- Kibojoe created with the Manjaro tools is 100% compatible with ManjaroLinux based on ArchLinux-
- Work-flow and efficiency optimized distribution on a rolling-release-
